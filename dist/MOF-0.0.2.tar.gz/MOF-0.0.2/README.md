# MOF
Mass-ratio-variance outlier factor (MOF) is a parameter-free outlier factor proposed by Krung Sinapiromsaran and Pitchapop.
